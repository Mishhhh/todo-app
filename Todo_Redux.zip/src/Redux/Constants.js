export const ActionTypes= {
    SET_TASKLIST:"Set_TaskList",
    SET_TASK:"Set_Task",
    REMOVE_TASK:"Remove_Task",
    UPDATE_TASK:"Update_Task"

};